# flowers-animation
Flowers-animation 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <link rel="stylesheet" href="https://rerofya.github.io/resources/flower.css">
    
    <title>rerofya</title>
</head>
<body>

    <div id="flower-container"></div>

    <script src="https://rerofya.github.io/resources/flower.js"></script>

</body>
</html>
